package dungeon;
public enum TypeOfTreasure {
    potion,
    gold,
    weapon,
    special
}
