package dungeon;
public enum TypeOfMonsters {
    goblin,
    orc,
    ogre,
    human
}
