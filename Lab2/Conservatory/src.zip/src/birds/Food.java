package birds;

public enum Food {
    berries,
    seeds,
    fruit,
    insects,
    otherBirds,
    eggs,
    smallMammals,
    fish,
    buds,
    larvae,
    aquaticInvertebrates,
    nuts,
    vegetation
}
