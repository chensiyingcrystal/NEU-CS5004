package birds;

abstract class NearWaterBirds extends AbstractBirds {
    String nameOfWaterBody;

    String getNameOfWaterBody() {
        return this.nameOfWaterBody;
    }


}
