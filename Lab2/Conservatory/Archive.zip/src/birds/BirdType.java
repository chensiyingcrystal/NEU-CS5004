package birds;

public enum BirdType {
    Hawks,
    Eagles,
    Osprey,
    Emus,
    Kiwis,
    Moas,
    Owls,
    RoseRingParakeet,
    GrayParrot,
    SulfurCrestedCockatoo,
    Pigeons,
    GreatAuk,
    HornedPuffin,
    AfricanJacana,
    Duck,
    Swan,
    Geese
}
