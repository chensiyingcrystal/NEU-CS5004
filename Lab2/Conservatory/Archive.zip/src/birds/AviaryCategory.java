package birds;

public enum AviaryCategory {
    Flightless,
    Prey,
    Waterfowl,
    Other

}
